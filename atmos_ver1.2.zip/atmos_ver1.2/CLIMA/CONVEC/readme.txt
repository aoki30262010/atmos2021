CLIMA/CONVEC
The subroutines in this subdirectory are used to calculate the moist
adiabat to calculate the convective temperature in the troposphere. 

The saturation pressure for CO2 and H2O is calculated by the subroutines
satco2.f and  satrat.f, respectively.

The relative humidity of the atmosphere is set by relhum.f
