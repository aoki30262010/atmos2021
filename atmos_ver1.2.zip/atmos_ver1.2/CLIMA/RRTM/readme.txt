CLIMA/RRTM

This subdirectory has the files for the RRTM code that calculate the IR fluxes.
The main program rrtm.f was modified to be coupled with the climate code,
the rest of the subroutines are intact. 

The version implemented here is 3.0 of the LWRRTM

Check the RRTM website for details about this code.
www.rtweb.aer.com

